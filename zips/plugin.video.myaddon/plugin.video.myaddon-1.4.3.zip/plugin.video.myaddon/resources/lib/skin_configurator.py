# -*- coding: utf-8 -*-
import sys
import os
import json
import time

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcplugin  # type: ignore
    import xbmcaddon  # type: ignore
    import xbmcvfs  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcplugin = _KodiMock()
    xbmcaddon = _KodiMock()
    xbmcvfs = _KodiMock()

def get_history_file():
    addon = xbmcaddon.Addon("plugin.video.myaddon")
    try:
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    except Exception:
        profile_path = os.path.expanduser("~")
    if not os.path.exists(profile_path):
        os.makedirs(profile_path)
    return os.path.join(profile_path, "history.json")

def save_to_history(title, action_url, poster="", backdrop="", media_type="movie", progress=0):
    history_file = get_history_file()
    history = []
    if os.path.exists(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                history = json.load(f)
        except Exception:
            history = []

    # Remove existing duplicate entry by title
    history = [item for item in history if item.get("title") != title]

    history.insert(0, {
        "title": title,
        "action_url": action_url,
        "poster": poster,
        "backdrop": backdrop,
        "media_type": media_type,
        "progress": progress,
        "timestamp": int(time.time())
    })

    # Keep top 30 items
    history = history[:30]

    try:
        with open(history_file, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception as e:
        xbmc.log(f"Save history error: {e}", xbmc.LOGERROR)

def get_history():
    history_file = get_history_file()
    if os.path.exists(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def clear_history():
    history_file = get_history_file()
    if os.path.exists(history_file):
        try:
            os.remove(history_file)
        except Exception:
            pass

def apply_container_view_mode(handle, mode_type="poster"):
    """
    Auto-formats Kodi skin view modes (Estuary, Aeon, Aura, Titan)
    """
    xbmcplugin.setContent(handle, "movies" if mode_type in ["poster", "movies"] else "episodes")
    view_ids = {
        "poster": "500",
        "movies": "50",
        "episodes": "504",
        "wall": "500"
    }
    target_id = view_ids.get(mode_type, "500")
    try:
        xbmc.executebuiltin(f"Container.SetViewMode({target_id})")
    except Exception:
        pass

def setup_kodi_home_nodes(show_dialog=False):
    """
    Programmatically creates custom Kodi Video Library Nodes so Kodi's main home screen
    navigation menu displays IsraelTV, Movies, TV Shows, Live TV, Last Seen, and Search natively!
    """
    try:
        try:
            userdata_dir = xbmcvfs.translatePath("special://userdata/library/video/")
        except Exception:
            userdata_dir = ""

        if not userdata_dir:
            return False

        if not os.path.exists(userdata_dir):
            os.makedirs(userdata_dir)

        addon_path = "special://home/addons/plugin.video.myaddon"

        nodes = [
            {
                "file": "01_israeltv.xml",
                "label": "🇮🇱 IsraelTV (ישראל TV)",
                "icon": f"{addon_path}/resources/images/kan.jpg",
                "path": "plugin://plugin.video.myaddon/?action=israeltv_categories",
                "order": "1"
            },
            {
                "file": "02_movies.xml",
                "label": "🎬 Movies (סרטים)",
                "icon": f"{addon_path}/icon.png",
                "path": "plugin://plugin.video.myaddon/?action=movie_categories",
                "order": "2"
            },
            {
                "file": "03_shows.xml",
                "label": "📺 TV Shows (סדרות)",
                "icon": f"{addon_path}/icon.png",
                "path": "plugin://plugin.video.myaddon/?action=show_categories",
                "order": "3"
            },
            {
                "file": "04_livetv.xml",
                "label": "📡 Live TV (IPTV)",
                "icon": f"{addon_path}/icon.png",
                "path": "plugin://plugin.video.myaddon/?action=live_tv_categories",
                "order": "4"
            },
            {
                "file": "05_lastseen.xml",
                "label": "🕒 Last Seen (נצפה לאחרונה)",
                "icon": f"{addon_path}/icon.png",
                "path": "plugin://plugin.video.myaddon/?action=show_last_seen",
                "order": "5"
            },
            {
                "file": "06_search.xml",
                "label": "🔍 Search (חיפוש)",
                "icon": f"{addon_path}/icon.png",
                "path": "plugin://plugin.video.myaddon/?action=search_menu",
                "order": "6"
            }
        ]

        for node in nodes:
            filepath = os.path.join(userdata_dir, node["file"])
            content = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>
<node order="{node['order']}" type="folder">
  <label>{node['label']}</label>
  <icon>{node['icon']}</icon>
  <path>{node['path']}</path>
</node>
"""
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)

        # Trigger Kodi skin refresh to display new home screen design
        xbmc.executebuiltin("ReloadSkin()")
        xbmc.executebuiltin("Container.Refresh()")

        if show_dialog:
            xbmcgui.Dialog().notification("Theme Installed", "Kodi home interface updated with IsraelTV VOD design!", xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f"Error setting up Kodi home nodes: {e}", xbmc.LOGERROR)
        return False
