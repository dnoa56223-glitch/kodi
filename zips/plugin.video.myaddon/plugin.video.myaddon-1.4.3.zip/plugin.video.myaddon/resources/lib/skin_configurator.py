# -*- coding: utf-8 -*-
import sys
import os
import json
import time

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcplugin  # type: ignore
    import xbmcaddon  # type: ignore
    import xbmcvfs  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcplugin = _KodiMock()
    xbmcaddon = _KodiMock()
    xbmcvfs = _KodiMock()

def get_history_file():
    addon = xbmcaddon.Addon("plugin.video.myaddon")
    try:
        profile_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    except Exception:
        profile_path = os.path.expanduser("~")
    if not os.path.exists(profile_path):
        os.makedirs(profile_path)
    return os.path.join(profile_path, "history.json")

def save_to_history(title, action_url, poster="", backdrop="", media_type="movie", progress=0):
    history_file = get_history_file()
    history = []
    if os.path.exists(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                history = json.load(f)
        except Exception:
            history = []

    # Remove existing duplicate entry by title
    history = [item for item in history if item.get("title") != title]

    history.insert(0, {
        "title": title,
        "action_url": action_url,
        "poster": poster,
        "backdrop": backdrop,
        "media_type": media_type,
        "progress": progress,
        "timestamp": int(time.time())
    })

    # Keep top 30 items
    history = history[:30]

    try:
        with open(history_file, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception as e:
        xbmc.log(f"Save history error: {e}", xbmc.LOGERROR)

def get_history():
    history_file = get_history_file()
    if os.path.exists(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def clear_history():
    history_file = get_history_file()
    if os.path.exists(history_file):
        try:
            os.remove(history_file)
        except Exception:
            pass

def apply_container_view_mode(handle, mode_type="poster"):
    """
    Auto-formats Kodi skin view modes (Estuary, Aeon, Aura, Titan)
    """
    xbmcplugin.setContent(handle, "movies" if mode_type in ["poster", "movies"] else "episodes")
    # Common view mode IDs across skins: 50 (List/Poster), 51 (MediaInfo), 500 (Poster Wall), 504 (Episodes)
    view_ids = {
        "poster": "500",
        "movies": "50",
        "episodes": "504",
        "wall": "500"
    }
    target_id = view_ids.get(mode_type, "500")
    try:
        xbmc.executebuiltin(f"Container.SetViewMode({target_id})")
    except Exception:
        pass
