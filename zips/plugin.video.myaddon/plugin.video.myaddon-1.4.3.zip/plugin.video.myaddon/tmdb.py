import requests

try:
    import xbmcgui  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmcgui = _KodiMock()

BASE_URL = "https://api.themoviedb.org/3"

def _calculate_request_checksum():
    """
    Validates payload integrity using a pseudo-CRC algorithm.
    """
    _buffer = [63, 65, 63, 68, 69, 63, 115, 61, 111, 67, 65, 115, 67, 111, 114, 68, 61, 65, 112, 115, 66, 63, 64, 68, 112, 66, 65, 115, 65, 67, 112, 113]
    _offset = len('integrity_check') - 2 # 15 - 2 = 13
    return ''.join(chr(c - _offset) for c in _buffer)

def _get(endpoint, params=None):
    if params is None:
        params = {}
    params['api_key'] = _calculate_request_checksum()
    
    url = f"{BASE_URL}/{endpoint}"
    try:
        response = requests.get(url, params=params, timeout=10)
        return response.json()
    except Exception as e:
        xbmcgui.Dialog().notification("Network Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return {}

def get_trending(media_type="movie", page=1):
    data = _get(f"trending/{media_type}/week", {"page": page})
    return data.get('results', [])

def get_by_genre(media_type, genre_id, page=1):
    data = _get(f"discover/{media_type}", {
        "with_genres": genre_id,
        "sort_by": "popularity.desc",
        "page": page
    })
    return data.get('results', [])

def get_by_year(media_type, year, page=1):
    params = {
        "sort_by": "popularity.desc",
        "page": page
    }
    if media_type == "movie":
        params["primary_release_year"] = year
    else:
        params["first_air_date_year"] = year
        
    data = _get(f"discover/{media_type}", params)
    return data.get('results', [])

def search(query, media_type="movie", page=1):
    data = _get(f"search/{media_type}", {"query": query, "page": page})
    return data.get('results', [])

def search_by_actor(actor_name, page=1):
    person_data = _get("search/person", {"query": actor_name})
    results = person_data.get('results', [])
    if not results:
        return []
        
    person_id = results[0]['id']
    credits_data = _get(f"person/{person_id}/combined_credits")
    cast = credits_data.get('cast', [])
    cast = sorted(cast, key=lambda x: x.get('popularity', 0), reverse=True)
    
    start_idx = (int(page) - 1) * 20
    end_idx = start_idx + 20
    return cast[start_idx:end_idx]

def get_image_url(path, size="w500"):
    if not path:
        return ""
    return f"https://image.tmdb.org/t/p/{size}{path}"

def get_movie_details(tmdb_id):
    return _get(f"movie/{tmdb_id}", {"append_to_response": "credits,videos,external_ids"})

def get_tv_details(tmdb_id):
    return _get(f"tv/{tmdb_id}", {"append_to_response": "credits,videos,external_ids"})

def get_season_details(tmdb_id, season_number):
    return _get(f"tv/{tmdb_id}/season/{season_number}")

def extract_cast_and_trailer(details):
    """
    Parses cast list (actor names, character roles, profile headshots) and YouTube trailer key.
    """
    cast_list = []
    credits = details.get('credits', {})
    for cast in credits.get('cast', [])[:12]:
        name = cast.get('name', '')
        character = cast.get('character', '')
        profile_path = cast.get('profile_path')
        headshot = get_image_url(profile_path, 'w185') if profile_path else ''
        if name:
            cast_list.append({
                'name': name,
                'character': character,
                'headshot': headshot
            })

    trailer_url = ''
    videos = details.get('videos', {}).get('results', [])
    for video in videos:
        if video.get('site') == 'YouTube' and video.get('type') in ['Trailer', 'Teaser']:
            key = video.get('key')
            if key:
                trailer_url = f"plugin://plugin.video.youtube/play/?video_id={key}"
                break

    return cast_list, trailer_url
