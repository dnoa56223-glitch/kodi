import sys
import urllib.parse
import os
import zipfile
import urllib.request

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcplugin  # type: ignore
    import xbmcaddon  # type: ignore
    import xbmcvfs  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcplugin = _KodiMock()
    xbmcaddon = _KodiMock()
    xbmcvfs = _KodiMock()

import tmdb
import iptv
import free_providers
import extractor

# Set up paths for embedded modules
resources_dir = os.path.join(os.path.dirname(__file__), 'resources')
if resources_dir not in sys.path:
    sys.path.insert(0, resources_dir)
lib_dir = os.path.join(resources_dir, 'lib')
if lib_dir not in sys.path:
    sys.path.insert(0, lib_dir)
idanplus_lib = os.path.join(lib_dir, 'idanplus')
if idanplus_lib not in sys.path:
    sys.path.insert(0, idanplus_lib)
engine_dir = os.path.join(lib_dir, 'engine')
if engine_dir not in sys.path:
    sys.path.insert(0, engine_dir)

import resources.idanplus_main as idanplus_main
import resources.lib.engine.torrent_server as torrent_server
import resources.lib.skin_configurator as skin_configurator

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_main_menu():
    skin_configurator.apply_container_view_mode(addon_handle, "poster")
    categories = [
        {'name': '[COLOR cyan][B]🇮🇱 IsraelTV (ישראל TV)[/B][/COLOR]', 'action': 'israeltv_categories'},
        {'name': '[COLOR gold][B]🎬 Movies (סרטים)[/B][/COLOR]', 'action': 'movie_categories'},
        {'name': '[COLOR gold][B]📺 TV Shows (סדרות)[/B][/COLOR]', 'action': 'show_categories'},
        {'name': '[COLOR lightblue][B]📡 Live TV (IPTV Global)[/B][/COLOR]', 'action': 'live_tv_categories'},
        {'name': '[COLOR lime][B]🕒 Last Seen (נצפה לאחרונה)[/B][/COLOR]', 'action': 'show_last_seen'},
        {'name': '[COLOR yellow][B]🔍 Search (חיפוש)[/B][/COLOR]', 'action': 'search_menu'},
        {'name': '[COLOR green][B]🎨 Apply / Refresh Kodi TV VOD Home Theme[/B][/COLOR]', 'action': 'apply_tv_theme'},
        {'name': '[COLOR grey][B]⚙️ Settings (הגדרות)[/B][/COLOR]', 'action': 'open_settings'}
    ]
    
    for category in categories:
        url = build_url({'action': category['action']})
        is_folder = category['action'] != 'open_settings'
        list_item = xbmcgui.ListItem(label=category['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=is_folder)
        
    xbmcplugin.endOfDirectory(addon_handle)

def open_settings():
    xbmcaddon.Addon().openSettings()

def israeltv_categories():
    categories = [
        {'name': '[COLOR cyan][B]IsraelTV - ערוצי טלויזיה (Live TV)[/B][/COLOR]', 'action': 'israeltv', 'mode': '1'},
        {'name': '[COLOR cyan][B]IsraelTV - ערוצי רדיו (Live Radio)[/B][/COLOR]', 'action': 'israeltv', 'mode': '3'},
        {'name': '[COLOR cyan][B]IsraelTV - תכניות ו-VOD (Israeli VOD)[/B][/COLOR]', 'action': 'israeltv', 'mode': '2'},
        {'name': '[COLOR cyan][B]IsraelTV - תכניות רדיו (Radio Shows)[/B][/COLOR]', 'action': 'israeltv', 'mode': '12'},
        {'name': '[COLOR cyan][B]IsraelTV - פודקאסטים (Podcasts)[/B][/COLOR]', 'action': 'israeltv', 'mode': '13'},
        {'name': '[COLOR cyan][B]IsraelTV - מוזיקה (Music)[/B][/COLOR]', 'action': 'israeltv', 'mode': '14'},
        {'name': '[COLOR yellow][B]IsraelTV - חיפוש תכניות (Search)[/B][/COLOR]', 'action': 'israeltv', 'mode': '4'},
        {'name': '[COLOR gold][B]IsraelTV - מועדפים (Favorites)[/B][/COLOR]', 'action': 'israeltv', 'mode': '10'}
    ]
    for cat in categories:
        url = build_url({'action': 'israeltv', 'mode': cat['mode']})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def live_tv_categories():
    categories = [
        {'name': 'All Global Channels', 'provider': 'global'},
        {'name': 'News', 'provider': 'news'},
        {'name': 'Sports', 'provider': 'sports'},
        {'name': 'Business & Finance', 'provider': 'business'},
        {'name': 'Entertainment', 'provider': 'entertainment'},
        {'name': 'Movies', 'provider': 'movies'},
        {'name': 'Pluto TV (Free Ad-Supported)', 'provider': 'pluto'},
        {'name': 'Samsung TV Plus', 'provider': 'samsung'}
    ]
    
    for cat in categories:
        url = build_url({'action': 'live_tv_menu', 'provider': cat['provider']})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def movie_categories():
    categories = [
        {'name': 'Trending', 'genre': ''},
        {'name': 'By Year', 'action': 'ask_movie_year'},
        {'name': 'Action', 'genre': '28'},
        {'name': 'Adventure', 'genre': '12'},
        {'name': 'Animation', 'genre': '16'},
        {'name': 'Comedy', 'genre': '35'},
        {'name': 'Crime', 'genre': '80'},
        {'name': 'Documentary', 'genre': '99'},
        {'name': 'Drama', 'genre': '18'},
        {'name': 'Family', 'genre': '10751'},
        {'name': 'Fantasy', 'genre': '14'},
        {'name': 'History', 'genre': '36'},
        {'name': 'Horror', 'genre': '27'},
        {'name': 'Music', 'genre': '10402'},
        {'name': 'Mystery', 'genre': '9648'},
        {'name': 'Romance', 'genre': '10749'},
        {'name': 'Sci-Fi', 'genre': '878'},
        {'name': 'Thriller', 'genre': '53'},
        {'name': 'War', 'genre': '10752'},
        {'name': 'Western', 'genre': '37'}
    ]
    
    for cat in categories:
        if 'action' in cat:
            url = build_url({'action': cat['action']})
        else:
            url = build_url({'action': 'list_movies', 'genre': cat['genre'], 'page': '1'})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def show_categories():
    categories = [
        {'name': 'Trending Today', 'genre': ''},
        {'name': 'By Year', 'action': 'ask_show_year'},
        {'name': 'Action & Adventure', 'genre': '10759'},
        {'name': 'Animation', 'genre': '16'},
        {'name': 'Comedy', 'genre': '35'},
        {'name': 'Crime', 'genre': '80'},
        {'name': 'Documentary', 'genre': '99'},
        {'name': 'Drama', 'genre': '18'},
        {'name': 'Family', 'genre': '10751'},
        {'name': 'Kids', 'genre': '10762'},
        {'name': 'Mystery', 'genre': '9648'},
        {'name': 'News', 'genre': '10763'},
        {'name': 'Reality', 'genre': '10764'},
        {'name': 'Sci-Fi & Fantasy', 'genre': '10765'},
        {'name': 'Soap', 'genre': '10766'},
        {'name': 'Talk', 'genre': '10767'},
        {'name': 'War & Politics', 'genre': '10768'},
        {'name': 'Western', 'genre': '37'}
    ]
    
    for cat in categories:
        if 'action' in cat:
            url = build_url({'action': cat['action']})
        else:
            url = build_url({'action': 'list_shows', 'genre': cat['genre'], 'page': '1'})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def live_tv_menu():
    provider = args.get('provider', ['global'])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Loading IPTV', 'Fetching channels...')
    pDialog.update(50)
    
    channels = iptv.get_channels(provider)
    
    pDialog.update(100)
    pDialog.close()
    
    if not channels:
        xbmcgui.Dialog().notification("No Channels", "Failed to load provider list.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for channel in channels:
        url = build_url({'action': 'play_video', 'video_url': channel['url']})
        list_item = xbmcgui.ListItem(label=f"[COLOR lime]● LIVE[/COLOR] {channel['name']}")
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def search_menu():
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Search", ["Search All", "Search Movies", "Search TV Shows", "Search by Actor"])
    
    if choice == 0:
        keyboard = xbmcgui.Keyboard('', 'Search All (Movies, Shows, Actors)')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'search_all', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    elif choice == 1:
        keyboard = xbmcgui.Keyboard('', 'Search for a Movie')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'search_movies', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    elif choice == 2:
        keyboard = xbmcgui.Keyboard('', 'Search for a TV Show')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'search_shows', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    elif choice == 3:
        keyboard = xbmcgui.Keyboard('', 'Search by Actor')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'do_search_actor', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    else:
        xbmcplugin.endOfDirectory(addon_handle)

def display_media(results, media_type, next_page_params=None):
    skin_configurator.apply_container_view_mode(addon_handle, "poster")
    if not results:
        xbmcgui.Dialog().notification("No Results", "Could not find any media.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for item in results:
        item_media_type = item.get('media_type', media_type)
        title = item.get('title') or item.get('name')
        media_id = item.get('id')
        date_str = item.get('release_date') or item.get('first_air_date')
        year = date_str.split('-')[0] if date_str else ""
        rating = item.get('vote_average', 0.0)
        rating_str = f"[COLOR gold]★ {rating:.1f}[/COLOR]" if rating else ""
            
        display_title = f"{title} ({year}) {rating_str}" if year else f"{title} {rating_str}"
        
        # Route to rich Media Details page
        url = build_url({
            'action': 'media_details',
            'tmdb_id': media_id,
            'media_type': item_media_type,
            'title': title
        })
        
        list_item = xbmcgui.ListItem(label=display_title)
        
        poster_path = item.get('poster_path')
        if poster_path:
            list_item.setArt({
                'thumb': tmdb.get_image_url(poster_path),
                'poster': tmdb.get_image_url(poster_path)
            })
            
        backdrop = item.get('backdrop_path')
        if backdrop:
            list_item.setArt({'fanart': tmdb.get_image_url(backdrop, 'w1280')})
                              
        list_item.setInfo('video', {
            'title': title, 
            'year': int(year) if year else 0, 
            'plot': item.get('overview', ''),
            'rating': float(rating) if rating else 0.0
        })
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    if next_page_params:
        next_url = build_url(next_page_params)
        next_item = xbmcgui.ListItem(label="Next Page ➔")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_url, listitem=next_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def media_details():
    """
    Renders an interactive Media Details tab featuring Synopsis, Rating, HD Trailer Button, 
    and Interactive Actor Headshots Carousel (clicking any actor searches their filmography).
    """
    skin_configurator.apply_container_view_mode(addon_handle, "movies")
    tmdb_id = args.get('tmdb_id', [''])[0]
    media_type = args.get('media_type', ['movie'])[0]
    title = args.get('title', ['Media'])[0]

    if media_type == "movie":
        details = tmdb.get_movie_details(tmdb_id)
    else:
        details = tmdb.get_tv_details(tmdb_id)

    cast_list, trailer_url = tmdb.extract_cast_and_trailer(details)

    overview = details.get('overview', 'No description available.')
    rating = details.get('vote_average', 0.0)
    date_str = details.get('release_date') or details.get('first_air_date') or ''
    year = date_str.split('-')[0] if date_str else ''
    poster_path = details.get('poster_path')
    backdrop_path = details.get('backdrop_path')

    # 1. Play Button Option
    if media_type == "movie":
        play_url = build_url({'action': 'smart_play_movie', 'tmdb_id': tmdb_id, 'title': title})
        play_item = xbmcgui.ListItem(label=f"[COLOR green][B]▶ PLAY MOVIE ({year})[/B][/COLOR]")
        play_item.setProperty('IsPlayable', 'true')
        is_folder = False
    else:
        play_url = build_url({'action': 'list_seasons', 'tmdb_id': tmdb_id, 'title': title})
        play_item = xbmcgui.ListItem(label=f"[COLOR green][B]▶ BROWSE SEASONS ({year})[/B][/COLOR]")
        is_folder = True

    if poster_path:
        play_item.setArt({'thumb': tmdb.get_image_url(poster_path), 'poster': tmdb.get_image_url(poster_path)})
    if backdrop_path:
        play_item.setArt({'fanart': tmdb.get_image_url(backdrop_path, 'w1280')})

    play_item.setInfo('video', {'title': title, 'plot': f"[COLOR gold]Rating: ★ {rating:.1f}/10[/COLOR]\n\n{overview}"})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=play_item, isFolder=is_folder)

    # 2. Watch Trailer Option
    if trailer_url:
        trailer_item = xbmcgui.ListItem(label="[COLOR red][B]🎬 WATCH OFFICIAL HD TRAILER[/B][/COLOR]")
        trailer_item.setProperty('IsPlayable', 'true')
        if backdrop_path:
            trailer_item.setArt({'fanart': tmdb.get_image_url(backdrop_path, 'w1280')})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=trailer_url, listitem=trailer_item, isFolder=False)

    # 3. Interactive Cast List (Actor headshots & roles)
    if cast_list:
        header_item = xbmcgui.ListItem(label="[COLOR yellow][B]🎭 CAST & ACTORS (Click to view filmography):[/B][/COLOR]")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url="#", listitem=header_item, isFolder=False)

        for actor in cast_list:
            actor_name = actor['name']
            role = actor['character']
            headshot = actor['headshot']
            actor_label = f"   👤 [COLOR white]{actor_name}[/COLOR] as [COLOR grey]{role}[/COLOR]"
            actor_url = build_url({'action': 'do_search_actor', 'query': actor_name, 'page': '1'})
            
            actor_item = xbmcgui.ListItem(label=actor_label)
            if headshot:
                actor_item.setArt({'thumb': headshot, 'icon': headshot})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=actor_url, listitem=actor_item, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def show_last_seen():
    """
    Displays recently played history items with progress indicators.
    """
    skin_configurator.apply_container_view_mode(addon_handle, "poster")
    history = skin_configurator.get_history()
    if not history:
        xbmcgui.Dialog().notification("Last Seen", "No recently watched history yet.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Clear History Option
    clear_url = build_url({'action': 'clear_last_seen'})
    clear_item = xbmcgui.ListItem(label="[COLOR red][B]🗑️ Clear Watch History[/B][/COLOR]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=clear_url, listitem=clear_item, isFolder=False)

    for item in history:
        title = item.get('title', 'Unknown')
        action_url = item.get('action_url', '')
        poster = item.get('poster', '')
        backdrop = item.get('backdrop', '')
        progress = item.get('progress', 0)
        
        progress_str = f" [COLOR lime]({progress}% watched)[/COLOR]" if progress > 0 else ""
        label = f"🕒 {title}{progress_str}"
        
        list_item = xbmcgui.ListItem(label=label)
        if poster:
            list_item.setArt({'thumb': poster, 'poster': poster})
        if backdrop:
            list_item.setArt({'fanart': backdrop})
        list_item.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=action_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def clear_last_seen():
    skin_configurator.clear_history()
    xbmcgui.Dialog().notification("History Cleared", "Watch history has been reset.", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh()")

def list_movies():
    genre = args.get('genre', [''])[0]
    page = int(args.get('page', ['1'])[0])
    
    if genre:
        results = tmdb.get_by_genre("movie", genre, page)
    else:
        results = tmdb.get_trending("movie", page)
        
    next_params = {'action': 'list_movies', 'genre': genre, 'page': str(page + 1)}
    display_media(results, "movie", next_params)

def list_shows():
    genre = args.get('genre', [''])[0]
    page = int(args.get('page', ['1'])[0])
    
    if genre:
        results = tmdb.get_by_genre("tv", genre, page)
    else:
        results = tmdb.get_trending("tv", page)
        
    next_params = {'action': 'list_shows', 'genre': genre, 'page': str(page + 1)}
    display_media(results, "tv", next_params)

def do_search_movies():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search(query, "movie", page)
    next_params = {'action': 'search_movies', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "movie", next_params)

def do_search_shows():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search(query, "tv", page)
    next_params = {'action': 'search_shows', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "tv", next_params)

def do_search_actor():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search_by_actor(query, page)
    next_params = {'action': 'do_search_actor', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "movie", next_params)

def do_search_all():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search(query, "multi", page)
    valid_results = [r for r in results if r.get('media_type') in ['movie', 'tv']]
    next_params = {'action': 'search_all', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(valid_results, "movie", next_params)

def do_ask_movie_year():
    dialog = xbmcgui.Dialog()
    year = dialog.numeric(0, 'Enter Year (e.g., 2024)')
    if year:
        url = build_url({'action': 'list_movies_by_year', 'year': year, 'page': '1'})
        xbmc.executebuiltin(f'Container.Update({url})')

def do_ask_show_year():
    dialog = xbmcgui.Dialog()
    year = dialog.numeric(0, 'Enter Year (e.g., 2024)')
    if year:
        url = build_url({'action': 'list_shows_by_year', 'year': year, 'page': '1'})
        xbmc.executebuiltin(f'Container.Update({url})')

def list_movies_by_year():
    year = args.get('year', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.get_by_year("movie", year, page)
    next_params = {'action': 'list_movies_by_year', 'year': year, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "movie", next_params)

def list_shows_by_year():
    year = args.get('year', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.get_by_year("tv", year, page)
    next_params = {'action': 'list_shows_by_year', 'year': year, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "tv", next_params)

def list_seasons():
    tmdb_id = args.get('tmdb_id', [''])[0]
    title = args.get('title', [''])[0]
    details = tmdb.get_tv_details(tmdb_id)
    seasons = details.get('seasons', [])
    for season in seasons:
        season_num = season.get('season_number')
        season_name = season.get('name')
        poster_path = season.get('poster_path')
        
        url = build_url({
            'action': 'list_episodes',
            'tmdb_id': tmdb_id,
            'season': season_num,
            'title': f"{title} - {season_name}"
        })
        list_item = xbmcgui.ListItem(label=season_name)
        if poster_path:
            list_item.setArt({
                'thumb': tmdb.get_image_url(poster_path),
                'poster': tmdb.get_image_url(poster_path)
            })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_episodes():
    tmdb_id = args.get('tmdb_id', [''])[0]
    season = args.get('season', [''])[0]
    title = args.get('title', [''])[0]
    
    details = tmdb.get_season_details(tmdb_id, season)
    episodes = details.get('episodes', [])
    
    for episode in episodes:
        ep_num = episode.get('episode_number')
        ep_name = episode.get('name')
        still_path = episode.get('still_path')
        overview = episode.get('overview', '')
        
        display_title = f"{ep_num}. {ep_name}"
        
        url = build_url({
            'action': 'smart_play_tv',
            'tmdb_id': tmdb_id,
            'season': season,
            'episode': ep_num,
            'title': f"{title} s{season}e{ep_num}"
        })
        
        list_item = xbmcgui.ListItem(label=display_title)
        if still_path:
            list_item.setArt({'thumb': tmdb.get_image_url(still_path)})
        list_item.setInfo('video', {'title': display_title, 'plot': overview, 'season': int(season), 'episode': int(ep_num)})
        list_item.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def smart_play_tv():
    title = args.get('title', [''])[0]
    tmdb_id = args.get('tmdb_id', [''])[0]
    season = args.get('season', [''])[0]
    episode = args.get('episode', [''])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Smart Play', 'Fetching TV Details from TMDB...')
    pDialog.update(25)
    
    details = tmdb.get_tv_details(tmdb_id)
    external_ids = details.get('external_ids', {})
    imdb_id = external_ids.get('imdb_id')
    poster_path = details.get('poster_path')
    backdrop_path = details.get('backdrop_path')
    
    if not imdb_id:
        pDialog.close()
        xbmcgui.Dialog().notification("Error", "No IMDB ID found for this show.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())
        return
    
    pDialog.update(50, 'Scraping Online Video Streams & Torrents...')
    streams = free_providers.get_tv_streams(imdb_id, season, episode, title)
    pDialog.update(100)
    pDialog.close()
    
    if not streams:
        xbmcgui.Dialog().notification("Extraction Failed", "Could not find any streams.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())
        return
        
    dialog = xbmcgui.Dialog()
    options = [s['title'] for s in streams]
    selected = dialog.select("Select Stream", options)
    
    if selected >= 0:
        stream_info = streams[selected]
        resolved_url = torrent_server.resolve_stream_url(stream_info)
        
        # Save to Watch History
        poster_url = tmdb.get_image_url(poster_path) if poster_path else ""
        backdrop_url = tmdb.get_image_url(backdrop_path, 'w1280') if backdrop_path else ""
        current_url = build_url({'action': 'smart_play_tv', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'title': title})
        skin_configurator.save_to_history(title, current_url, poster_url, backdrop_url, "tv", 0)

        play_item = xbmcgui.ListItem(path=resolved_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())

def smart_play_movie():
    title = args.get('title', [''])[0]
    tmdb_id = args.get('tmdb_id', [''])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Smart Play', 'Fetching Movie Details from TMDB...')
    pDialog.update(25)
    
    details = tmdb.get_movie_details(tmdb_id)
    imdb_id = details.get('imdb_id')
    poster_path = details.get('poster_path')
    backdrop_path = details.get('backdrop_path')
    
    if not imdb_id:
        pDialog.close()
        xbmcgui.Dialog().notification("Error", "No IMDB ID found for this movie.", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())
        return

    pDialog.update(50, 'Scraping Online Video Streams & Torrents...')
    streams = free_providers.get_movie_streams(imdb_id, title)
    pDialog.update(100)
    pDialog.close()
    
    if not streams:
        xbmcgui.Dialog().notification("Extraction Failed", "Could not find any streams.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())
        return
        
    dialog = xbmcgui.Dialog()
    options = [s['title'] for s in streams]
    selected = dialog.select("Select Stream", options)
    
    if selected >= 0:
        stream_info = streams[selected]
        resolved_url = torrent_server.resolve_stream_url(stream_info)
        
        # Save to Watch History
        poster_url = tmdb.get_image_url(poster_path) if poster_path else ""
        backdrop_url = tmdb.get_image_url(backdrop_path, 'w1280') if backdrop_path else ""
        current_url = build_url({'action': 'smart_play_movie', 'tmdb_id': tmdb_id, 'title': title})
        skin_configurator.save_to_history(title, current_url, poster_url, backdrop_url, "movie", 0)

        play_item = xbmcgui.ListItem(path=resolved_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())

def play_video():
    video_url = args.get('video_url', [''])[0]
    play_item = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def apply_tv_theme():
    skin_configurator.setup_kodi_home_nodes(show_dialog=True)

def router(paramstring):
    action = args.get('action', [None])[0]
    mode = args.get('mode', [None])[0]
    module = args.get('module', [None])[0]
    
    if action == 'israeltv' or mode is not None or module is not None:
        idanplus_main.route(sys.argv[2])
        return

    if action is None:
        list_main_menu()
    elif action == 'open_settings':
        open_settings()
    elif action == 'apply_tv_theme':
        apply_tv_theme()
    elif action == 'israeltv_categories':
        israeltv_categories()
    elif action == 'live_tv_categories':
        live_tv_categories()
    elif action == 'movie_categories':
        movie_categories()
    elif action == 'show_categories':
        show_categories()
    elif action == 'live_tv_menu':
        live_tv_menu()
    elif action == 'list_movies':
        list_movies()
    elif action == 'list_shows':
        list_shows()
    elif action == 'media_details':
        media_details()
    elif action == 'show_last_seen':
        show_last_seen()
    elif action == 'clear_last_seen':
        clear_last_seen()
    elif action == 'search_menu':
        search_menu()
    elif action == 'search_movies':
        do_search_movies()
    elif action == 'search_shows':
        do_search_shows()
    elif action == 'do_search_actor':
        do_search_actor()
    elif action == 'search_all':
        do_search_all()
    elif action == 'ask_movie_year':
        do_ask_movie_year()
    elif action == 'ask_show_year':
        do_ask_show_year()
    elif action == 'list_movies_by_year':
        list_movies_by_year()
    elif action == 'list_shows_by_year':
        list_shows_by_year()
    elif action == 'smart_play_movie':
        smart_play_movie()
    elif action == 'smart_play_tv':
        smart_play_tv()
    elif action == 'list_seasons':
        list_seasons()
    elif action == 'list_episodes':
        list_episodes()
    elif action == 'play_video':
        play_video()

if __name__ == '__main__':
    router(sys.argv[2][1:])
