# -*- coding: utf-8 -*-
import sys
import os

resources_dir = os.path.join(os.path.dirname(__file__), 'resources')
if resources_dir not in sys.path:
    sys.path.insert(0, resources_dir)
lib_dir = os.path.join(resources_dir, 'lib')
if lib_dir not in sys.path:
    sys.path.insert(0, lib_dir)

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcaddon  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcaddon = _KodiMock()

import skin_configurator

def main():
    xbmc.log("plugin.video.myaddon background service started: Applying Kodi TV VOD home design...", xbmc.LOGINFO)
    xbmc.sleep(2000)
    skin_configurator.setup_kodi_home_nodes(show_dialog=False)

if __name__ == "__main__":
    main()
