# -*- coding: utf-8 -*-
import sys
import os

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcaddon  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcaddon = _KodiMock()

def main():
    # Background service worker for plugin.video.myaddon
    xbmc.log("plugin.video.myaddon background service started.", xbmc.LOGINFO)

if __name__ == "__main__":
    main()
