# -*- coding: utf-8 -*-
import sys
import os
import time
import urllib.parse
import requests

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcplugin  # type: ignore
    import xbmcaddon  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcplugin = _KodiMock()
    xbmcaddon = _KodiMock()

def resolve_stream_url(stream_info):
    """
    Resolves a stream object (direct URL, magnet, or web stream) into a playable HTTP(S) video URL for Kodi.
    """
    magnet = stream_info.get('magnet', '')
    url = stream_info.get('url', '')
    info_hash = stream_info.get('info_hash', '')

    # 1. Direct Web Video URL or HLS (.m3u8 / .mp4)
    if url and ('http://' in url or 'https://' in url) and not url.startswith('magnet:'):
        return url

    # 2. Try ResolveURL for Debrid (Real-Debrid, Premiumize, AllDebrid, TorBox)
    try:
        import resolveurl  # type: ignore
        if magnet and resolveurl.HostedMediaFile(magnet).valid():
            resolved = resolveurl.resolve(magnet)
            if resolved:
                return resolved
    except Exception as e:
        xbmc.log(f"ResolveURL attempt error: {e}", xbmc.LOGINFO)

    # 3. Direct Torrentio Stream / HTTP Proxy fallback
    if info_hash:
        file_idx = stream_info.get('file_idx', 0)
        # Torrentio public HTTP stream gateway
        public_stream = f"https://torrentio.strem.fun/stream/play/{info_hash}/{file_idx}"
        try:
            resp = requests.head(public_stream, timeout=5, allow_redirects=True)
            if resp.status_code in [200, 206, 301, 302]:
                return resp.url if resp.url else public_stream
        except Exception:
            pass

    # 4. Return original magnet or URL if available
    return url if url else magnet
