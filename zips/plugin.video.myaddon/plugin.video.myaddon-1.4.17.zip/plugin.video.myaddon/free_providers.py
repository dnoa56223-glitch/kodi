import requests
import urllib.parse
import re

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/html, */*'
}

def get_movie_streams(imdb_id, title="Movie"):
    """
    Fetch both Direct Web HLS streams and Torrents for Movies
    """
    streams = []

    # 1. Direct Web Stream: VidSrc & MultiEmbed
    web_streams = _get_direct_web_streams("movie", imdb_id)
    streams.extend(web_streams)

    # 2. Torrent Streams: Torrentio & YTS
    torrent_streams = _get_movie_torrents(imdb_id)
    streams.extend(torrent_streams)

    return streams

def get_tv_streams(imdb_id, season, episode, title="TV Show"):
    """
    Fetch both Direct Web HLS streams and Torrents for TV Episodes
    """
    streams = []

    # 1. Direct Web Stream: VidSrc & MultiEmbed
    web_streams = _get_direct_web_streams("tv", imdb_id, season, episode)
    streams.extend(web_streams)

    # 2. Torrent Streams: Torrentio & EZTV
    torrent_streams = _get_tv_torrents(imdb_id, season, episode)
    streams.extend(torrent_streams)

    return streams

def _get_direct_web_streams(media_type, imdb_id, season=None, episode=None):
    web_streams = []

    # Provider A: VidSrc
    if media_type == "movie":
        vidsrc_url = f"https://vidsrc.me/embed/movie?imdb={imdb_id}"
    else:
        vidsrc_url = f"https://vidsrc.me/embed/tv?imdb={imdb_id}&s={season}&e={episode}"

    web_streams.append({
        'title': '[⚡ FAST STREAM] VidSrc Online Player (1080p Auto)',
        'url': vidsrc_url,
        'type': 'web'
    })

    # Provider B: MultiEmbed / SuperEmbed
    if media_type == "movie":
        multi_url = f"https://multiembed.mov/directstream.php?video_id={imdb_id}"
    else:
        multi_url = f"https://multiembed.mov/directstream.php?video_id={imdb_id}&s={season}&e={episode}"

    web_streams.append({
        'title': '[⚡ FAST STREAM] SuperEmbed HD (Fast Server)',
        'url': multi_url,
        'type': 'web'
    })

    return web_streams

def _get_movie_torrents(imdb_id):
    streams = []

    # 1. Torrentio API
    url = f"https://torrentio.strem.fun/stream/movie/{imdb_id}.json"
    try:
        response = requests.get(url, headers=HEADERS, timeout=8)
        if response.status_code == 200:
            data = response.json()
            streams.extend(_parse_torrentio_streams(data.get('streams', [])))
    except Exception as e:
        print(f"Torrentio Movie Error: {e}")

    # 2. YTS API
    yts_url = f"https://yts.mx/api/v2/movie_details.json?imdb_id={imdb_id}"
    try:
        yts_resp = requests.get(yts_url, headers=HEADERS, timeout=8)
        if yts_resp.status_code == 200:
            yts_data = yts_resp.json()
            for torrent in yts_data.get('data', {}).get('movie', {}).get('torrents', []):
                hash_val = torrent.get('hash')
                quality = torrent.get('quality')
                size = torrent.get('size')
                if hash_val:
                    title = f"[YTS.mx] {quality} ({size})"
                    magnet = f"magnet:?xt=urn:btih:{hash_val}&dn={imdb_id}"
                    streams.append({
                        'title': title,
                        'magnet': magnet,
                        'info_hash': hash_val,
                        'type': 'torrent'
                    })
    except Exception as e:
        print(f"YTS Error: {e}")

    return streams

def _get_tv_torrents(imdb_id, season, episode):
    streams = []

    # 1. Torrentio API
    url = f"https://torrentio.strem.fun/stream/series/{imdb_id}:{season}:{episode}.json"
    try:
        response = requests.get(url, headers=HEADERS, timeout=8)
        if response.status_code == 200:
            data = response.json()
            streams.extend(_parse_torrentio_streams(data.get('streams', [])))
    except Exception as e:
        print(f"Torrentio TV Error: {e}")

    # 2. EZTV API
    eztv_url = f"https://eztvx.to/api/get-torrents?imdb_id={imdb_id.replace('tt', '')}"
    try:
        eztv_resp = requests.get(eztv_url, headers=HEADERS, timeout=8)
        if eztv_resp.status_code == 200:
            eztv_data = eztv_resp.json()
            for torrent in eztv_data.get('torrents', []):
                if str(torrent.get('season', '')) == str(season) and str(torrent.get('episode', '')) == str(episode):
                    hash_val = torrent.get('hash')
                    filename = torrent.get('title')
                    if hash_val:
                        title = f"[EZTV.to] {filename}"
                        magnet = torrent.get('magnet_url', f"magnet:?xt=urn:btih:{hash_val}&dn={urllib.parse.quote(filename)}")
                        streams.append({
                            'title': title,
                            'magnet': magnet,
                            'info_hash': hash_val,
                            'type': 'torrent'
                        })
    except Exception as e:
        print(f"EZTV Error: {e}")

    return streams

def _parse_torrentio_streams(streams):
    parsed = []
    for stream in streams:
        if 'infoHash' in stream:
            info_hash = stream['infoHash']
            title = stream.get('title', 'Unknown Title')
            name = stream.get('name', 'Torrent')
            file_idx = stream.get('fileIdx', 0)

            dn = urllib.parse.quote(title.split('\n')[0])
            magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={dn}"
            display_title = f"[{name.replace(chr(10), ' ')}] {title.split(chr(10))[0]}"

            parsed.append({
                'title': display_title,
                'magnet': magnet,
                'info_hash': info_hash,
                'file_idx': file_idx,
                'type': 'torrent'
            })
    return parsed

# Compatibility aliases
get_movie_torrents = get_movie_streams
get_tv_torrents = get_tv_streams
