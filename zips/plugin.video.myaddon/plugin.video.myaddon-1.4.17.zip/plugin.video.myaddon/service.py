# -*- coding: utf-8 -*-
import sys
import os

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcaddon  # type: ignore
except ImportError:
    class _KodiMock:
        def __getattr__(self, name):
            return lambda *args, **kwargs: None
    xbmc = _KodiMock()
    xbmcgui = _KodiMock()
    xbmcaddon = _KodiMock()

def main():
    # Background service worker for plugin.video.myaddon
    xbmc.log("plugin.video.myaddon background service started.", xbmc.LOGINFO)
    
    addon = xbmcaddon.Addon()
    if addon.getSetting('skin_switched') != 'true':
        xbmc.log("Auto-setting skin to skin.myvodapp on first run", xbmc.LOGINFO)
        # Execute JSON-RPC to change the skin
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.myvodapp"},"id":1}')
        # Mark as switched so we don't force it every time they boot Kodi
        addon.setSetting('skin_switched', 'true')

if __name__ == "__main__":
    main()
