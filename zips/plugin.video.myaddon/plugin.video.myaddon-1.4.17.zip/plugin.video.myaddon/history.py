import os
import json
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
try:
    # Kodi 19+
    PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
except NameError:
    # Kodi 18
    PROFILE_DIR = xbmc.translatePath(ADDON.getAddonInfo('profile'))

if not os.path.exists(PROFILE_DIR):
    os.makedirs(PROFILE_DIR)
HISTORY_FILE = os.path.join(PROFILE_DIR, 'recent_channels.json')
VOD_HISTORY_FILE = os.path.join(PROFILE_DIR, 'recent_vod.json')

def add_channel(name, full_url, icon):
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                history = json.load(f)
        else:
            history = []
    except Exception:
        history = []
        
    # Remove existing entry for this channel (by name) to move it to the top
    history = [c for c in history if c['name'] != name]
    
    # Add to top
    history.insert(0, {'name': name, 'url': full_url, 'icon': icon})
    
    # Keep only last 10
    history = history[:10]
    
    try:
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=4)
    except Exception as e:
        xbmc.log(f"Failed to save channel history: {e}", xbmc.LOGERROR)

def get_channels():
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"Failed to load channel history: {e}", xbmc.LOGERROR)
    return []

def add_vod(name, full_url, icon, fanart=""):
    try:
        if os.path.exists(VOD_HISTORY_FILE):
            with open(VOD_HISTORY_FILE, 'r', encoding='utf-8') as f:
                history = json.load(f)
        else:
            history = []
    except Exception:
        history = []
        
    history = [c for c in history if c['name'] != name]
    history.insert(0, {'name': name, 'url': full_url, 'icon': icon, 'fanart': fanart})
    history = history[:20]
    
    try:
        with open(VOD_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=4)
    except Exception as e:
        xbmc.log(f"Failed to save VOD history: {e}", xbmc.LOGERROR)

def get_vod():
    try:
        if os.path.exists(VOD_HISTORY_FILE):
            with open(VOD_HISTORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log(f"Failed to load VOD history: {e}", xbmc.LOGERROR)
    return []
