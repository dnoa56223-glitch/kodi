import requests
import urllib.parse

def search_movie(title, year=""):
    """
    Searches the Internet Archive for a public domain movie.
    Returns a direct MP4 link if found, otherwise None.
    """
    # Clean up title for search
    query_title = urllib.parse.quote(title)
    
    # We restrict to media type movies and format mp4
    url = f"https://archive.org/advancedsearch.php?q=title:({query_title}) AND mediatype:(movies)&fl[]=identifier,title,format&output=json&rows=5"
    
    try:
        response = requests.get(url, timeout=10).json()
        docs = response.get('response', {}).get('docs', [])
        
        if not docs:
            return None
            
        # For simplicity, we just grab the first result's identifier
        # and construct the standard download URL for a 512kb mp4 or similar
        best_match = docs[0]
        identifier = best_match.get('identifier')
        
        if identifier:
            # Let's try to get the metadata to find the exact mp4 file
            meta_url = f"https://archive.org/metadata/{identifier}"
            meta_resp = requests.get(meta_url, timeout=10).json()
            files = meta_resp.get('files', [])
            
            # Find the first mp4 file
            for f in files:
                if f.get('name', '').endswith('.mp4'):
                    return f"https://archive.org/download/{identifier}/{f['name']}"
                    
    except Exception as e:
        print(f"Archive.org search error: {e}")
        
    return None
