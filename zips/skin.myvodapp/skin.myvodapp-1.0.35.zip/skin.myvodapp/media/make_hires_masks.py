import os
from PIL import Image, ImageDraw

def make_rounded_mask(width, height, radius, filename, fill_color=(255, 255, 255, 255)):
    # Create an image with transparent background
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw rounded rectangle
    try:
        draw.rounded_rectangle((0, 0, width, height), radius=radius, fill=fill_color)
    except AttributeError:
        # Fallback for older Pillow
        draw.rectangle((radius, 0, width - radius, height), fill=fill_color)
        draw.rectangle((0, radius, width, height - radius), fill=fill_color)
        draw.pieslice((0, 0, radius * 2, radius * 2), 180, 270, fill=fill_color)
        draw.pieslice((width - radius * 2, 0, width, radius * 2), 270, 360, fill=fill_color)
        draw.pieslice((0, height - radius * 2, radius * 2, height), 90, 180, fill=fill_color)
        draw.pieslice((width - radius * 2, height - radius * 2, width, height), 0, 90, fill=fill_color)

    # Save
    img.save(filename)
    print(f"Generated {filename}")

if __name__ == "__main__":
    # Generate Poster Mask (200x300) with 12px radius
    make_rounded_mask(200, 300, 12, "poster_mask.png")
    
    # Generate Landscape Mask (320x180) with 12px radius
    make_rounded_mask(320, 180, 12, "landscape_mask.png")
    
    # Generate larger focus glow masks
    # Poster focus glow
    make_rounded_mask(240, 340, 20, "poster_glow.png")
    
    # Landscape focus glow
    make_rounded_mask(360, 220, 20, "landscape_glow.png")
