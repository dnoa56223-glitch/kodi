import zlib
import struct
import os

def make_png(width, height, pixels):
    raw_data = b''
    for y in range(height):
        raw_data += b'\x00'
        for x in range(width):
            r, g, b, a = pixels[y * width + x]
            raw_data += struct.pack('4B', r, g, b, a)
    idat = zlib.compress(raw_data)
    def chunk(type_, data):
        return struct.pack('>I', len(data)) + type_ + data + struct.pack('>I', zlib.crc32(type_ + data) & 0xffffffff)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', idat) + chunk(b'IEND', b'')
    return png

width = 64
height = 64
radius = 16

# 1. roundbox.png
pixels = []
for y in range(height):
    for x in range(width):
        r, g, b, a = 255, 255, 255, 255
        dx = dy = 0
        if x < radius: dx = radius - x - 0.5
        elif x >= width - radius: dx = x - (width - radius - 1) - 0.5
        if y < radius: dy = radius - y - 0.5
        elif y >= height - radius: dy = y - (height - radius - 1) - 0.5
        if dx > 0 and dy > 0:
            dist = (dx**2 + dy**2)**0.5
            if dist > radius: a = 0
            elif dist > radius - 1: a = int(255 * (radius - dist))
        pixels.append((r, g, b, a))

with open('roundbox.png', 'wb') as f:
    f.write(make_png(width, height, pixels))

# 2. glow.png
pixels_glow = []
for y in range(height):
    for x in range(width):
        r, g, b = 255, 255, 255
        dx = abs(x - width/2.0)
        dy = abs(y - height/2.0)
        # soft exponential dropoff for a nice glow
        dist = (dx**2 + dy**2)**0.5 / (width/2.0)
        if dist > 1.0:
            a = 0
        else:
            a = int(255 * (1.0 - dist)**2)
        pixels_glow.append((r, g, b, a))

with open('glow.png', 'wb') as f:
    f.write(make_png(width, height, pixels_glow))
