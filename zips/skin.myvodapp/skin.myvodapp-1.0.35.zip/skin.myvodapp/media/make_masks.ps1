Add-Type -AssemblyName System.Drawing

function Draw-RoundedRectangle ($g, $pen, $bounds, $radius) {
    $diameter = $radius * 2
    $size = New-Object System.Drawing.Size($diameter, $diameter)
    $arc = New-Object System.Drawing.Rectangle($bounds.Location, $size)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath

    if ($radius -eq 0) {
        $path.AddRectangle($bounds)
        return $path
    }

    # Top left arc
    $path.AddArc($arc, 180, 90)

    # Top right arc
    $arc.X = $bounds.Right - $diameter
    $path.AddArc($arc, 270, 90)

    # Bottom right arc
    $arc.Y = $bounds.Bottom - $diameter
    $path.AddArc($arc, 0, 90)

    # Bottom left arc
    $arc.X = $bounds.Left
    $path.AddArc($arc, 90, 90)

    $path.CloseFigure()
    
    $g.FillPath($pen, $path)
}

function Create-Mask ($width, $height, $radius, $filename, $color) {
    $bitmap = New-Object System.Drawing.Bitmap($width, $height)
    $g = [System.Drawing.Graphics]::FromImage($bitmap)
    
    # Set high quality rendering for smooth corners
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

    $bounds = New-Object System.Drawing.Rectangle(0, 0, $width, $height)
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb($color.A, $color.R, $color.G, $color.B))

    Draw-RoundedRectangle -g $g -pen $brush -bounds $bounds -radius $radius

    $g.Dispose()
    $brush.Dispose()

    $filepath = Join-Path (Get-Location) $filename
    $bitmap.Save($filepath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
    Write-Host "Generated $filename"
}

# 1. Poster Mask (200x300, 12px radius)
Create-Mask -width 200 -height 300 -radius 12 -filename "poster_mask.png" -color ([System.Drawing.Color]::FromArgb(255, 255, 255, 255))

# 2. Landscape Mask (320x180, 12px radius)
Create-Mask -width 320 -height 180 -radius 12 -filename "landscape_mask.png" -color ([System.Drawing.Color]::FromArgb(255, 255, 255, 255))

# 3. Poster Glow (240x340, 20px radius)
Create-Mask -width 240 -height 340 -radius 20 -filename "poster_glow.png" -color ([System.Drawing.Color]::FromArgb(255, 255, 255, 255))

# 4. Landscape Glow (360x220, 20px radius)
Create-Mask -width 360 -height 220 -radius 20 -filename "landscape_glow.png" -color ([System.Drawing.Color]::FromArgb(255, 255, 255, 255))
