# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import json
import time
import platform
import os
import urllib.request
import zipfile

TORREST_VERSION = "0.0.22"

def log(msg):
    xbmc.log(f"[IsrTV Installer] {msg}", xbmc.LOGINFO)

def is_torrest_up_to_date():
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.torrest')
        version = addon.getAddonInfo('version')
        if version == TORREST_VERSION:
            return True
    except Exception:
        pass
    return False

def get_torrest_platform():
    os_name = ""
    if xbmc.getCondVisibility('system.platform.android'):
        os_name = "android"
    elif xbmc.getCondVisibility('system.platform.linux'):
        os_name = "linux"
    elif xbmc.getCondVisibility('system.platform.windows'):
        os_name = "windows"
    elif xbmc.getCondVisibility('system.platform.osx') or xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
        os_name = "darwin"
    else:
        # Fallback using python platform
        sys_name = platform.system().lower()
        if 'windows' in sys_name:
            os_name = "windows"
        elif 'linux' in sys_name:
            os_name = "linux"
        elif 'darwin' in sys_name:
            os_name = "darwin"
            
    if not os_name:
        os_name = "windows" # Fallback

    is_64bits = platform.machine().endswith('64') or '64' in platform.architecture()[0]
    is_arm = 'arm' in platform.machine().lower() or 'aarch' in platform.machine().lower()
    
    if os_name == "windows":
        return "windows_x64" if is_64bits else "windows_x86"
    elif os_name == "android":
        if is_arm:
            return "android_arm64" if is_64bits else "android_arm"
        return "android_x64" if is_64bits else "android_x86"
    elif os_name == "linux":
        if is_arm:
            return "linux_arm64" if is_64bits else "linux_armv7"
        return "linux_x64" if is_64bits else "linux_x86"
    elif os_name == "darwin":
        return "darwin_x64"
        
    return "windows_x64" # Ultimate fallback

def run():
    # Ensure Torrest is always enabled, in case it was disabled by a previous crash
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"plugin.video.torrest","enabled":true},"id":1}')
    
    # Check if Torrest is installed and is the correct version
    if is_torrest_up_to_date():
        log("Torrest is already installed and up to date. Exiting auto-downloader.")
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create("IsrTV 1-Click Installer", "Starting Torrest setup...")
    
    try:
        dialog.update(10, "Detecting device architecture...")
        torrest_platform = get_torrest_platform()
        log(f"Detected Torrest platform: {torrest_platform}")
        
        # 1. Download Torrest
        zip_name = f"plugin.video.torrest-{TORREST_VERSION}.{torrest_platform}.zip"
        zip_url = f"https://github.com/i96751414/plugin.video.torrest/releases/download/v{TORREST_VERSION}/{zip_name}"
        
        addons_dir = xbmcvfs.translatePath('special://home/addons/')
        zip_dest = os.path.join(addons_dir, zip_name)
        
        dialog.update(30, f"Downloading Torrest engine for {torrest_platform}...")
        req = urllib.request.Request(zip_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response, open(zip_dest, 'wb') as out_file:
            out_file.write(response.read())

        # 2. Extract Torrest
        dialog.update(60, "Extracting Torrest engine...")
        with zipfile.ZipFile(zip_dest, 'r') as zip_ref:
            zip_ref.extractall(addons_dir)
            
        try:
            os.remove(zip_dest)
        except Exception:
            pass

        # 3. Update Kodi internal addon database
        dialog.update(80, "Updating Kodi database...")
        xbmc.executebuiltin('UpdateLocalAddons')
        time.sleep(2)
        
        # 4. Enable Torrest via JSON-RPC
        dialog.update(85, "Enabling Torrest...")
        rpc_query = {
            "jsonrpc": "2.0",
            "method": "Addons.SetAddonEnabled",
            "params": {"addonid": "plugin.video.torrest", "enabled": True},
            "id": 1
        }
        xbmc.executeJSONRPC(json.dumps(rpc_query))

        # 5. Switch Skin
        dialog.update(90, "Applying IsrTV Skin...")
        rpc_skin = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {"setting": "lookandfeel.skin", "value": "skin.myvodapp"},
            "id": 1
        }
        xbmc.executeJSONRPC(json.dumps(rpc_skin))

        dialog.update(100, "Setup Complete!")
        time.sleep(1)
        dialog.close()
        
        xbmcgui.Dialog().ok("Installation Complete", "IsrTV and Torrest have been successfully installed!\nKodi will now reload the skin.")
        xbmc.executebuiltin('ReloadSkin')

    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Installation Error", f"An error occurred:\n{str(e)}")
        log(f"Error: {e}")

if __name__ == '__main__':
    run()
