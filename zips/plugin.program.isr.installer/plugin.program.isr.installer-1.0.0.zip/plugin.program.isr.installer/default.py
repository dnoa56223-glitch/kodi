# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import json
import time

def log(msg):
    xbmc.log(f"[IsrTV Installer] {msg}", xbmc.LOGINFO)

def run():
    dialog = xbmcgui.DialogProgress()
    dialog.create("IsrTV 1-Click Installer", "Finalizing setup...")
    
    try:
        dialog.update(50, "Applying IsrTV Skin...")
        time.sleep(1)
        
        # Switch Skin using JSON-RPC
        rpc_skin = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {"setting": "lookandfeel.skin", "value": "skin.myvodapp"},
            "id": 1
        }
        xbmc.executeJSONRPC(json.dumps(rpc_skin))

        dialog.update(100, "Setup Complete!")
        time.sleep(1)
        dialog.close()
        
        xbmcgui.Dialog().ok("Installation Complete", "IsrTV has been successfully installed!", "Kodi will now reload the skin.")
        xbmc.executebuiltin('ReloadSkin')

    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Installation Error", f"An error occurred:\n{str(e)}")
        log(f"Error: {e}")

if __name__ == '__main__':
    run()
